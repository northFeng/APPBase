//
//  APPVideoPromptView.h
//  CleverBaby
//  提示亮度、音量调试
//  Created by 峰 on 2020/2/7.
//  Copyright © 2020 小神童. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface APPVideoPromptView : UIView

+ (APPVideoPromptView *)showAlertFromView:(UIView *)onView;

@end

NS_ASSUME_NONNULL_END
